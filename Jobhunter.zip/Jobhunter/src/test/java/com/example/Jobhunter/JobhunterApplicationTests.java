package com.example.Jobhunter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobhunterApplicationTests {

	@Test
	void contextLoads() {
	}

}
